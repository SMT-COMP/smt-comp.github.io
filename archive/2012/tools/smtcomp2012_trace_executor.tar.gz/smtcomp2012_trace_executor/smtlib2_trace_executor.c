/* -*- C++ -*-
 *
 * A simple SMT-LIB v2 trace executor.
 * 
 * Author: Alberto Griggio <griggio@fbk.eu>
 *
 * Copyright (C) 2011 Alberto Griggio
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>
#include <assert.h>

#define USE_FORKPTY 0 /* set to 1 to use PTYs -- MUCH slower */

#if USE_FORKPTY
#  include <pty.h>
#endif

typedef enum { STATUS_CMD, STATUS_EOF, STATUS_CHECK, STATUS_ERROR } send_status;


static double get_time_sec(void)
{
    struct timeval tv;
    double total;
    
    gettimeofday(&tv, NULL);
    total = (double)(tv.tv_sec) + (double)(tv.tv_usec) / 1000000.0;
    return total;
}


typedef struct {
    char *data;
    size_t idx;
    size_t size;
} Buffer;


static void init_buf(Buffer *buf)
{
    buf->data = malloc(4096);
    buf->size = 4096;
    buf->idx = 0;
}


static void putbuf(Buffer *buf, char c)
{
    assert(buf->data);
    if (buf->idx == buf->size) {
        buf->size *= 2;
        buf->data = realloc(buf->data, buf->size);
    }
    buf->data[buf->idx++] = c;
}


static send_status get_next_cmd(FILE *in, Buffer *sendbuf)
{
    send_status status = STATUS_CMD;
    int first = 1;
    int comment = 0;
    int found = 0;
    int parens = 0;
    int escaped = 0;
    int quoted = 0;
    const char *check_sat_cmd = "check-sat";
    int check_sat_idx = -1;

    while (1) {
        int e;
        int c = fgetc(in);
        if (c == EOF) {
            return STATUS_EOF;
        }
        if (comment) {
            check_sat_idx = -1;
            if (c == '\n') {
                comment = 0;
            }
            goto sendc;
        }
        if (c == '\\') {
            escaped = !escaped;
            goto sendc;
        }
        e = escaped;
        escaped = 0;
        if (!e || quoted) {
            if (c == '|') {
                check_sat_idx = -1;
                quoted = !quoted;
                goto sendc;
            }
            if (!quoted) {
                switch (c) {
                case ';':
                    comment = 1;
                    check_sat_idx = -1;
                    break;
                case '|':
                    quoted = 1;
                    check_sat_idx = -1;
                    break;
                case '(':
                    ++parens;
                    first = 0;
                    if (parens == 1) {
                        check_sat_idx = 0;
                    } else {
                        check_sat_idx = -1;
                    }
                    break;
                case ')':
                    --parens;
                    if (parens == 0 && check_sat_idx == 9) {
                        status = STATUS_CHECK;
                    }
                    check_sat_idx = -1;
                    break;
                default:
                    if (check_sat_idx >= 0 && check_sat_idx < 9) {
                        if (!isspace(c)) {
                            if (c == check_sat_cmd[check_sat_idx]) {
                                ++check_sat_idx;
                            } else {
                                check_sat_idx = -1;
                            }
                        }
                    } else if (check_sat_idx == 9) {
                        if (!isspace(c)) {
                            check_sat_idx == -1;
                        }
                    } else {
                        check_sat_idx = -1;
                    }
                }
            }
        } else {
            check_sat_idx = -1;
        }

      sendc:
        putbuf(sendbuf, c);
        if (parens == 0 && !first) {
            return status;
        }
    }
}


static int str_eq_skipws(const char *s, const char *target)
{
    const char *c = s;
    size_t l = strlen(target);
    while (*c && isspace(*c)) ++c;
    if (strncmp(c, target, l) == 0) {
        c += l;
        while (*c) {
            if (!isspace(*c)) return 0;
            ++c;
        }
        return 1;
    } else {
        return 0;
    }
}


static const char *get_line(FILE *src, Buffer *buf)
{
    assert(buf->data);

    buf->idx = 0;
    while (1) {
        int c = fgetc(src);
        if (c == EOF) {
            break;
        }
        putbuf(buf, c);
        if (c == '\n') {
            break;
        }
    }
    putbuf(buf, 0);
    return buf->data;
}


static double solver_time = 0;
static int query_count = 0;

static void print_result(void)
{
    printf("SOLVED %d PROBLEMS IN %.3f SECONDS\n",
           query_count, solver_time);
    fflush(stdout);
}


static void sigint_handler(int signum)
{
    print_result();
    exit(0);
}


#define SKIPWS(s, out)                              \
    while (*s) {                                    \
        if (!isspace(*s)) {                         \
            fputc(*s, out);                         \
        }                                           \
        ++s;                                        \
    }


#define EXIT_WRONG_RESULT 2
#define EXIT_ERROR        1


static void usage(const char *progname)
{
    printf("Usage: %s [-solutions SOLUTIONS_FILE] [-querycount N] SOLVER SOLVER_ARGS... < BENCHMARK\n", progname);
    exit(EXIT_ERROR);
}


int main(int argc, char **argv)
{
    pid_t pid;
    int fds_to[2];
    int fds_from[2];
    FILE *to_child;
    FILE *from_child;
    int from_child_fd;
    send_status st;
    int status;
    const char *response = NULL;
    size_t len = 0;
    char **execargs = NULL;
    int i;
    double start_time, end_time, tot_time;
    FILE *solutions = NULL;
    const char *solutions_fn = NULL;
    int first_non_opt = 1;
    Buffer sendbuf;
    Buffer recvbuf;
    Buffer solbuf;
    int max_query_count = 0;

    if (argc < 2) {
        usage(argv[0]);
    }

    for (first_non_opt = 1; first_non_opt < argc; ++first_non_opt) {
        if (strcmp(argv[first_non_opt], "-solutions") == 0) {
            if (argc > first_non_opt+1) {
                solutions_fn = argv[first_non_opt+1];
                ++first_non_opt;
            } else {
                usage(argv[0]);
            }
        } else if (strcmp(argv[first_non_opt], "-help") == 0 ||
                   strcmp(argv[first_non_opt], "-h") == 0) {
            usage(argv[0]);
        } else if (strcmp(argv[first_non_opt], "-querycount") == 0) {
            if (argc > first_non_opt+1) {
                max_query_count = atoi(argv[first_non_opt+1]);
                if (!max_query_count &&
                    strcmp(argv[first_non_opt+1], "0") != 0) {
                    usage(argv[0]);
                }
                ++first_non_opt;
            } else {
                usage(argv[0]);
            }
        } else if (argv[first_non_opt][0] == '-') {
            printf("Unrecognized option: %s\n", argv[first_non_opt]);
            usage(argv[0]);
        } else {
            break;
        }
    }
    if (first_non_opt >= argc) {
        usage(argv[0]);
    }

    if (pipe(fds_to) != 0 || pipe(fds_from) != 0) {
        return EXIT_ERROR;
    }

#if USE_FORKPTY
    pid = forkpty(&from_child_fd, NULL, NULL, NULL);
#else
    pid = fork();
#endif
    if (pid == 0) {
        close(fds_to[1]);
        dup2(fds_to[0], 0);
#if !USE_FORKPTY
        close(fds_from[0]);
        dup2(fds_from[1], 1);
#endif

        execargs = malloc(sizeof(const char *) * (argc - first_non_opt + 1));
        for (i = first_non_opt; i < argc; ++i) {
            execargs[i-first_non_opt] = argv[i];
        }
        execargs[argc-1] = NULL;
        
        execv(execargs[0], execargs);
        printf("ERROR executing: %s\n", execargs[0]);
        return EXIT_ERROR;
    } else if (pid < 0) {
        return EXIT_ERROR;
    }

    if (solutions_fn != NULL) {
        solutions = fopen(solutions_fn, "r");
        if (!solutions) {
            printf("ERROR opening solutions file %s\n", argv[1]);
            return EXIT_ERROR;
        }
    }
    
    close(fds_to[0]);
    to_child = fdopen(fds_to[1], "w");
#if USE_FORKPTY
    from_child = fdopen(from_child_fd, "r");
#else
    close(fds_from[1]);
    from_child = fdopen(fds_from[0], "r");
#endif

    start_time = 0;
    tot_time = 0;
    signal(SIGINT, sigint_handler);

    init_buf(&sendbuf);
    init_buf(&recvbuf);
    if (solutions) {
        init_buf(&solbuf);
    }

    fputs("(set-option :print-success true)\n", to_child);
    fflush(to_child);
    response = get_line(from_child, &recvbuf);
    if (!str_eq_skipws(response, "success")) {
        printf("BAD output from solver: %s\n", response);
        fflush(stdout);
        print_result();
        return EXIT_ERROR;
    }

    while (1) {
        st = get_next_cmd(stdin, &sendbuf);
        if (st == STATUS_EOF) {
          print_final_result:
            fputs("\n(exit)\n", to_child);
            fflush(to_child);
            wait(&status);

            print_result();
            
            return 0;
        }

        start_time = get_time_sec();
        fwrite(sendbuf.data, 1, sendbuf.idx, to_child);
        sendbuf.idx = 0;
        fputc('\n', to_child);
        fflush(to_child);
        
        switch (st) {
        case STATUS_CMD:
            response = get_line(from_child, &recvbuf);
            end_time = get_time_sec();
            tot_time += (end_time - start_time);
            
            if (!str_eq_skipws(response, "success")) {
                printf("BAD output from solver: %s\n", response);
                fflush(stdout);
                print_result();
                return EXIT_ERROR;
            }
            break;

        case STATUS_CHECK:
            response = get_line(from_child, &recvbuf);
            end_time = get_time_sec();
            tot_time += (end_time - start_time);

            if (!str_eq_skipws(response, "sat") &&
                !str_eq_skipws(response, "unsat")) {
                printf("BAD output from solver: %s\n", response);
                fflush(stdout);
                print_result();
                return EXIT_ERROR;
            } else {
                if (solutions) {
                    const char *expected = get_line(solutions, &solbuf);
                    /* trim comments */
                    for (i = 0; expected[i]; ++i) {
                        if (isspace(expected[i]) || expected[i] == '#') {
                            ((char *)expected)[i] = 0;
                            break;
                        }
                    }
                    if (!str_eq_skipws(expected, "sat") &&
                        !str_eq_skipws(expected, "unsat") &&
                        !str_eq_skipws(expected, "unknown")) {
                        printf("BAD expected result: %s\n", expected);
                        print_result();
                        return EXIT_ERROR;
                    }
                    if (!str_eq_skipws(expected, "unknown") &&
                        !str_eq_skipws(response, expected)) {
                        const char *s = response;
                        printf("ERROR in solver response: got ");
                        SKIPWS(s, stdout);
                        printf(", expected ");
                        s = expected;
                        SKIPWS(s, stdout);
                        fputc('\n', stdout);
                        fflush(stdout);
                        solver_time = 0;
                        query_count = 0;
                        print_result();
                        return EXIT_WRONG_RESULT;
                    }
                }
                solver_time = tot_time;
                ++query_count;
                const char *s = response;
                SKIPWS(s, stdout);
                fputc('\n', stdout);
                fflush(stdout);

                if (query_count == max_query_count) {
                    goto print_final_result;
                }
            }
            break;
            
        }
    }

    return 0;
}
